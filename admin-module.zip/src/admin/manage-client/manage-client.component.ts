import { Component } from "@angular/core";

@Component({
    selector: 'manage-clients',
    templateUrl: './manage-client.component.html'
})
export class ManageClientsComponent{

}