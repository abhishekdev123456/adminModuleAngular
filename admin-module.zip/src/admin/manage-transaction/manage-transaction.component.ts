import { Component } from "@angular/core";

@Component({
    selector: 'manage-transaction',
    templateUrl: './manage-transaction.component.html'
})
export class ManageTransactionComponent{

}