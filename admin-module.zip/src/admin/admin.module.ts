import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ManageClientsComponent } from './manage-client/manage-client.component';
import { ManageTransactionComponent } from './manage-transaction/manage-transaction.component';
import { ManageAccountComponent } from './manage-account/manage-account.component';
@NgModule({
  declarations: [
    AdminComponent,
    DashboardComponent,
    ManageClientsComponent,
    ManageTransactionComponent,
    ManageAccountComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule
  ],
  exports: [AdminComponent],
  providers: []
})
export class AdminModule { }
