import { Component } from "@angular/core";

@Component({
    selector: 'admin',
    templateUrl: './admin.component.html',
    styleUrls: ['./styles/layout.less']
})
export class AdminComponent{

}