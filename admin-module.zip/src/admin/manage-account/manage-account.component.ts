import { Component } from "@angular/core";

@Component({
    selector: 'manage-account',
    templateUrl: './manage-account.component.html'
})
export class ManageAccountComponent{

}
